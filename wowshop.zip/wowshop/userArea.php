 <?php


 include 'header.php';


 ?>

 <h3 class="text-center">Welcome to your profile</h3>


 <?php include 'footer.php';?>
