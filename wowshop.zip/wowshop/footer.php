
<footer>

 <div class="container-fluid">




     <div class="row">




         <div class="col-sm-4">

             <h3>Navigation</h3>

             <ul >

                 <li> <a href="index.php"><span class="glyphicon glyphicon-home"></span> Home</a></li>

                 <li><a href="#"><span class="glyphicon glyphicon-shopping-cart"></span> Shop</a></li>

                 <li> <a a href="about.php"><span class="glyphicon glyphicon-info-sign"></span> About </a> </li>

                 <li><a href="contactus.php"><span class="glyphicon glyphicon-envelope"></span> Contact</a> </li>

                 <li><a href="map.php"><span class="glyphicon glyphicon-map-marker"></span> Map </a></li>

             </ul>

         </div>


         <div class="col-sm-4">

             <h3>Contact Info</h3>

             <ul>

                 <li><p><span><i class="glyphicon glyphicon-envelope"></i></span> wowshop@support.com</p> </li>


                 <li><p><span><i class="glyphicon glyphicon-earphone "></i></span> Phone:+962065371982</p> </li>


                 <li><p><span><i class="	glyphicon glyphicon-map-marker"></i></span> 00962 , Petra street, Amman, Jordan</p> </li>
             </ul>


         </div>


         <div class="col-sm-4">


             <h3>Social</h3>

             <ul class="list-inline">


                 <li><a href="#"><span><i class="fa fa-facebook-square fa-2x" aria-hidden="true"></i> </span> </a> </li>

                 <li><a href="#"> <span><i class="fa fa-google-plus fa-2x" aria-hidden="true"></i></span>  </a></li>

                 <li><a href="#"><span><i class="fa fa-twitter-square fa-2x" aria-hidden="true"></i></span> </a>  </li>




             </ul>

         </div>





     </div>


     <p  class="text-center">&copy;WowShop</p>
</div>



<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>



<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
 <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.15.0/jquery.validate.js"></script>


    <script src="javascript/contact.js"></script>


    <script src="javascript/signup.js"></script>





</footer>



</body>









</html>
