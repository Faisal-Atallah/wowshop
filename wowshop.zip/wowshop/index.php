
<!-- import header -->

<?php include 'header.php';?>


<!--import slider  -->

<?php include 'slider.php';?>


<!--import services -->

<?php include 'services.php'?>

<!--import products page --->


<?php include 'products.php' ?>


<!-- import galary -->

<?php include 'galary.php'?>


<!-- import footer -->

<?php include 'footer.php';?>
        





        
