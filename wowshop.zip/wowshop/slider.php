

<div id="MainCarousel" class=" carousel slide carousel-fade" data-ride="carousel">
    <!-- Indicators -->
    <ol class="carousel-indicators">
        <li data-target="#MainCarousel" data-slide-to="0" class="active"></li>
        <li data-target="#MainCarousel" data-slide-to="1"></li>

    </ol>
    <!-- Wrapper for slides -->
    <div class="carousel-inner" role="listbox">

        <div class="item active">
            <img src="image/slider31.jpg" alt="Chicago">


            <div class="carousel-caption">
                <h3>SUMMER 2017 FASHION TRENDS</h3>

            </div>
        </div>

        <div class="item">
            <img src="image/slider32.jpg" alt="Chicago">



            <div class="carousel-caption">
                <h3>HOT SALE SUMMER</h3>

            </div>

        </div>



    </div>


    <!-- Left and right controls -->
    <a  class="left carousel-control hidden-xs" href="#MainCarousel" data-slide="prev"> &lsaquo; </a>
    <a class="right carousel-control hidden-xs" href="#MainCarousel" data-slide="next"> &rsaquo; </a>
</div>