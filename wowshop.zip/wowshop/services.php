 <div class="container services">




     <div class="row services">



         <div class="col-sm-3">


                 <img src="image/fast-delivery.png" alt="fast shipping"/>

             <p>FREE SHIPPING</p>
             <p>Delivery world wide</p>






         </div>

         <div class="col-sm-3">



             <img src="image/telemarketer.png" alt="call support"/>


             <p class="eve">WE SUPPORT</p>
             <p>Online store 24/7</p>

         </div>


         <div class="col-sm-3">


             <img src="image/fast-delivery.png" alt="delivery"/>

             <p>HOTLINE</p>


             <p> Phone: +123.666.888</p>


         </div>


         <div class="col-sm-3">


                 <img src="image/credit-card.png" alt="credit card"/>

             <p class="eve">MONEY BACK</p>


             <p>While not exactly line</p>

         </div>




     </div>



 </div>
