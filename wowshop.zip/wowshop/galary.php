
<!-- images container-->

<div class="container">


<div class="well well-sm">

<div class="flex-container">

      <!-- first image-->
    <div class="flex-item"><img class="img-responsive" src="image/gallery1.jpg" ></div>
    
      <!-- second image-->
    <div class="flex-item"> <img class="img-responsive" src="image/gallery7.jpg" ></div>
     
     <!-- thrid image-->
    <div class="flex-item"><img class="img-responsive" src="image/gallery5.jpg" ></div>

       <!-- 4th image-->
  <div class="flex-item"><img class="img-responsive" src="image/gallery2.jpg" > </div>
</div>



</div>
</div>



